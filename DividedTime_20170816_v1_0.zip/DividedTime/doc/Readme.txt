Garmin Watchface

20170816_V1.0

DividedTime is an easy to use and configurable watchface. It uses a left (hours) and right (minutes) part that can be configured by its foreground and background. Enjoy :-)

V1.0:
Configurable in:
-Foreground left part (hours)
-Background left part (hours)
-Foreground right part (minutes)
-Foreground right part (minutes)
-Background right part (minutes)
-Show battery state at and lower than: 100%, 50%, 25% or 10%
-Show date
-Show day of week instead of month (when date is shown)