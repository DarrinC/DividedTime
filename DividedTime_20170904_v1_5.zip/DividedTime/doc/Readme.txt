Garmin Watchface DIVIDEDTIME

Versions:
20170816_V1.0
20170820_V1.1
20170823_V1.2
20170826_V1.3
20170830_V1.4
20170903_V1.5

Github url: https://github.com/gcoder75/DividedTime

Description:
DividedTime is an easy to use and configurable watchface. It uses a left (hours) and right (minutes) part that can be configured in varieties of ways. Enjoy :-)

New:
V1.5 - Please remove older versions before installing this version
-Timestyle left (hours): normal H, thicker H, normal HH, thicker HH
-Timestyle right (minutes): normal mm, smaller mm, tiny mm, tiny mmss* 
   *Support seconds only for Fenix 5 and FR935 by their Always On feature
-Datestyle: hide, DofW | DD, Month | DD, (D)D | Month, DD | MM, MM | DD, DDMM | YYYY, YYYY | MMDD, MMDD | YYYY
-Some text and code optimizations done

V1.4
-Option for text size minutes: normal, smaller and tiny
-Option for balanced 11 hour and 10 to 19 minutes
-Add color Sky Blue (only on newer devices, like Fenix 5 / Chronos and FR935)
-Add ‘active minutes’ to alternative today’s data (only CIQ 2.x devices)

V1.3
-Clear rendering number 5
-New colors: Cyan Blue, Lime Green and High Yellow (only visible on newer devices, like Fenix 5 / Chronos and FR935)

V1.2
-Show zero leading for hours
-Thicker text for hours
-Smaller text for minutes
-Display -- for notifications (Notf) when there is no connection with the phone
-Some code optimizations

V1.1
-Some code and graphic view optimizations
-Add 33% and 5% for Show battery state
-Add alternative today’s data to display when batter state is not displayed:
	notifications count, calories, step goal % or steps

V1.0
Configurable in:
-Foreground left part (hours)
-Background left part (hours)
-Foreground right part (minutes)
-Background right part (minutes)
-Show battery state at and lower than: 100%, 50%, 25% or 10%
-Show date
-Show day of week instead of month (when date is shown)
