Garmin Watchface DIVIDEDTIME

Versions:
20170816_V1.0
20170820_V1.1
20170823_V1.2
20170826_V1.3
20170830_V1.4

Github url: https://github.com/gcoder75/DividedTime

Description:
DividedTime is an easy to use and configurable watchface. It uses a left (hours) and right (minutes) part that can be configured by its foreground, background and more. Enjoy :-)

New:
V1.4
-Option for text size minutes: normal, smaller and tiny
-Option for balanced 11 hour and 10 to 19 minutes
-Add color Sky Blue (only on newer devices, like Fenix 5 / Chronos and FR935)
-Add ‘active minutes’ to alternative today’s data (only CIQ 2.x devices)

V1.3
-Clear rendering number 5
-New colors: Cyan Blue, Lime Green and High Yellow (only visible on newer devices, like Fenix 5 / Chronos and FR935)

V1.2
-Show zero leading for hours
-Thicker text for hours
-Smaller text for minutes
-Display -- for notifications (Notf) when there is no connection with the phone
-Some code optimizations

V1.1
-Some code and graphic view optimizations
-Add 33% and 5% for Show battery state
-Add alternative today’s data to display when batter state is not displayed:
	notifications count, calories, step goal % or steps

V1.0
Configurable in:
-Foreground left part (hours)
-Background left part (hours)
-Foreground right part (minutes)
-Background right part (minutes)
-Show battery state at and lower than: 100%, 50%, 25% or 10%
-Show date
-Show day of week instead of month (when date is shown)
