Garmin Watchface

Versions:
20170816_V1.0
20170820_V1.1
20170823_V1.2


Github url: https://github.com/gcoder75/DividedTime

Description:
DividedTime is an easy to use and configurable watchface. It uses a left (hours) and right (minutes) part that can be configured by its foreground, background and more. Enjoy :-)

New:
V1.2
-Show zero leading for hours
-Thicker text for hours
-Smaller text for minutes
-Display -- for notifications (Notf) when there is no connection with the phone
-Some code optimizations

V1.1
-Some code and graphic view optimizations
-Add 33% and 5% for Show battery state
-Add alternative data to display when batter state is not displayed:
	notifications count, calories, step goal % or steps

V1.0
Configurable in:
-Foreground left part (hours)
-Background left part (hours)
-Foreground right part (minutes)
-Background right part (minutes)
-Show battery state at and lower than: 100%, 50%, 25% or 10%
-Show date
-Show day of week instead of month (when date is shown)
