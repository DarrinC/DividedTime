Garmin Watchface DIVIDED|TIME

Versions:
20170816_V1.0
20170820_V1.1
20170823_V1.2
20170826_V1.3
20170830_V1.4
20170903_V1.5
20170906_V1.6
20170913_V1.7
20170926_V1.8
20171019_V1.9
20171111_V1.9.1
20171204_V1.9.2
20171218_V2.0

Github url: https://github.com/gcoder75/DividedTime

Description:
IMPORTANT: DividedTime is an easy to use and configurable watchface with a plain design. It uses a left (hours) part and right (minutes) part that can be configured in a variety of ways. Enjoy styling!
HIGHLIGHTS: 
-24* colors to configure foregrounds and backgrounds
-4 styles for hours, include zero leading
-3 styles for minutes for all devices
-1* style for minute and second* for newer devices only, like Fenix 5
-10 right upper data, to keep focused on the data you want
-11 left upper data to be focused on, including 3 graphic bars
-10 styles for date, from short to long
-Show batterylevel at and lower than the specified value

*only on Fenix 5, FR935, AS60, Charlie, VA3; marked in App settings with +

New:
Remove any previous version of this app from your watch before upgrading! Please contact me by using the contact developer link when you encounter any App errors or having new ideas.
VERSIONS:
V2.0
-Add to left upper data: movement bar, stepgoal bar, stepgoal history of 5 days, 'movement and stepgoal' bar
-Add to right upper data: step goal history of 7 days, movement priority as text
-Textlabel and placement update for App Settings
-Code optimizations


V1.9.2
-Add support for Vivoactive 3
-Some textlabels changed for App Settings

V1.9.1
-Add some options to 'Show alternative data' and 'Left part'.

V1.9
-Compact text labels in App Settings Garmin Mobile or Express
-Add 'Phone Connected State' and 'Alarm Count' to left alternative data

V1.8
-Add support for Garmin’s: Approach S60, D2 Bravo (Titanium), D2 Charlie
-Left part alternative today’s data configurable with; label, notifications, battery state, steps, total active minutes
-Restyling time font number 1
-Add 0% to ’Show battery state at or lower than’
-Add date style ‘day of week | DDMM’, ‘day of week | MMDD’
-Large code restyling

V1.7
-Time font pixel rendering improvement for sharper and cleaner display of time digits

V1.6
-Add to alternative today’s: floor climbed, active minutes total, active minutes vigorous (only CIQ 2.x devices)
-Supporting now 24 colors on Fenix 5 / Chronos and FR935
-Add colors: Salmon, Fuchsia, Sun Yellow, Soft Red, Light Purple (Fenix 5 / Chronos and FR935)
-Reordering colors in App Settings

V1.5
-Timestyle left (hours): normal H, thicker H, normal HH, thicker HH. (HH stands for Zero leading)
-Timestyle right (minutes): normal mm, smaller mm, tiny mm, tiny mmss* 
   *Support seconds only for Fenix 5 and FR935 by their Always On feature
-Datestyle: supporting 8 different date styles
-Some text and code optimizations done

V1.4
-Option for text size minutes: normal, smaller and tiny
-Option for balanced 11 hour and 10 to 19 minutes
-Add color Sky Blue (Fenix 5 / Chronos and FR935)
-Add ‘active minutes’ to alternative today’s data (only CIQ 2.x devices)

V1.3
-Clear rendering number 5
-New colors: Cyan Blue, Lime Green and High Yellow (Fenix 5 / Chronos and FR935)

V1.2
-Show zero leading for hours
-Thicker text for hours
-Smaller text for minutes
-Display -- for notifications (Notf) when there is no connection with the phone
-Some code optimizations

V1.1
-Some code and graphic view optimizations
-Add 33% and 5% for Show battery state
-Add alternative today’s data to display when batter state is not displayed:
	notifications count, calories, step goal % or steps

V1.0
Configurable in:
-Foreground left part (hours)
-Background left part (hours)
-Foreground right part (minutes)
-Background right part (minutes)
-Show battery state at and lower than: 100%, 50%, 25% or 10%
-Show date
-Show day of week instead of month (when date is shown)